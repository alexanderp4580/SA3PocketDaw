import { describe, it, expect } from 'vitest';
import { createEngine, type EngineContextLike } from './engine';
import { log } from '../log';
import { createProject, addTrack, addNote, setTrackSample, setRoot } from '../store/projectModel';

function fakeCtx() {
  const started: Array<{ rate: number; when: number; until:number; buffer: unknown }> = [];
  const buffers: Array<{ ch: number; len: number; sr: number; data: Float32Array | null }> = [];
  const state = { time: 0, resumed: 0, current: 'suspended', created: 0 };
  const mk = (): EngineContextLike => ({
    get currentTime() { return state.time; },
    get state() { return state.current; },
    destination: 'dest',
    async resume() { state.resumed++; state.current = 'running'; },
    createBuffer(ch, len, sr) {
      const rec = { ch, len, sr, data: null as Float32Array | null };
      buffers.push(rec);
      return { duration: len / sr, copyToChannel(d: Float32Array) { rec.data = d; } };
    },
    createGain() {
      return { gain: { value: 1, setValueAtTime() {}, linearRampToValueAtTime() {} }, connect() {} };
    },
    createBufferSource() {
      const rec = { rate: 1, when: -1, buffer: null as unknown,until:-1 };
      started.push(rec);
      return {
        get buffer() { return rec.buffer as never; }, set buffer(b) { rec.buffer = b; },
        playbackRate: { get value() { return rec.rate; }, set value(v: number) { rec.rate = v; }, setValueAtTime() {}, linearRampToValueAtTime() {} },
        onended: null, connect() {}, start(w?: number) { rec.when = w ?? 0; }, stop(t?:number) {rec.until=t??0;},
      };
    },
  });
  return { mk, started, buffers, state };
}

function proj() {
  let p = createProject({ bars: 1, bpm: 120 });
  p = addTrack(p, 'A', 't1');
  p = setTrackSample(setRoot(p, 't1', 60), 't1', 's1');
  p = addNote(p, 't1', { midi: 72, start: 0, length: 2 });
  return p;
}

describe('engine', () => {
  it('previews the original source without repitching',async()=>{const f=fakeCtx(),e=createEngine({createContext:f.mk});await e.previewSource(new Float32Array(4410),44100);expect(f.started[0]!.rate).toBe(1);expect(f.buffers[0]!.len).toBe(4410);});
  it('creates and resumes the context only on unlock, once', async () => {
    const f = fakeCtx();
    let created = 0;
    const e = createEngine({ createContext: () => { created++; return f.mk(); } });
    expect(created).toBe(0);
    await e.unlock();
    await e.unlock();
    expect(created).toBe(1);
    expect(f.state.resumed).toBe(1);
  });

  it('audition plays at the right rate from a cached buffer', async () => {
    const f = fakeCtx();
    const e = createEngine({ createContext: f.mk });
    e.setProject(proj());
    e.setSample('s1', new Float32Array(4410), 44100);
    await e.audition('t1', 72);
    expect(f.started).toHaveLength(1);
    expect(f.started[0]!.rate).toBeCloseTo(2);
    expect(f.buffers).toHaveLength(1);
    expect(f.buffers[0]).toMatchObject({ ch: 1, len: 4410, sr: 44100 });
    await e.audition('t1', 60);
    expect(f.buffers).toHaveLength(1); // cached
  });

  it('does nothing for tracks without a sample', async () => {
    const f = fakeCtx();
    const e = createEngine({ createContext: f.mk });
    e.setProject(addTrack(createProject(), 'x', 'tx'));
    await e.audition('tx', 60);
    expect(f.started).toHaveLength(0);
  });

  it('plays the pattern through the scheduler and stops', async () => {
    const f = fakeCtx();
    const timers: Array<() => void> = [];
    const e = createEngine({ createContext: f.mk, setTimer: (fn) => { timers.push(fn); return timers.length; }, clearTimer: () => timers.splice(0) });
    e.setProject(proj());
    e.setSample('s1', new Float32Array(44100), 44100);
    await e.play();
    expect(e.isPlaying).toBe(true);
    expect(f.started).toHaveLength(1);
    expect(f.started[0]!.rate).toBeCloseTo(2);
    f.state.time = 0.3;
    expect(e.playhead()).toBeCloseTo(2, 3);
    e.stop();
    expect(e.isPlaying).toBe(false);
    expect(e.playhead()).toBe(0);
  });

  it('skips notes that a stalled main thread delivered long after their time, but plays slightly late ones', async () => {
    const f = fakeCtx();
    const timers: Array<() => void> = [];
    const e = createEngine({ createContext: f.mk, setTimer: (fn) => { timers.push(fn); return timers.length; }, clearTimer: () => timers.splice(0) });
    let p = createProject({ bars: 2, bpm: 120 });
    p = addTrack(p, 'A', 't1');
    p = setTrackSample(setRoot(p, 't1', 60), 't1', 's1');
    p = addNote(p, 't1', { midi: 72, start: 0, length: 2 });
    p = addNote(p, 't1', { midi: 60, start: 8, length: 1 });
    p = addNote(p, 't1', { midi: 62, start: 16, length: 1 });
    p = addNote(p, 't1', { midi: 64, start: 24, length: 1 });
    e.setProject(p);
    e.setSample('s1', new Float32Array(44100), 44100);
    await e.play();
    expect(f.started).toHaveLength(1);
    // 1.05 s (midi 60) is 0.95 s old at 2.0 s and is dropped; 2.05 s (midi 62) is on time.
    f.state.time = 2.0;
    timers.splice(0).forEach((fn) => fn());
    expect(f.started).toHaveLength(2);
    expect(f.started[1]!.rate).toBeCloseTo(2 ** (2 / 12));
    // 3.05 s (midi 64) delivered 60 ms late still plays.
    f.state.time = 3.11;
    timers.splice(0).forEach((fn) => fn());
    expect(f.started).toHaveLength(3);
  });

  it('reports a backlog of stale notes as one warning with a count and the largest lateness', async () => {
    const f = fakeCtx();
    const timers: Array<() => void> = [];
    const e = createEngine({ createContext: f.mk, setTimer: (fn) => { timers.push(fn); return timers.length; }, clearTimer: () => timers.splice(0) });
    let p = createProject({ bars: 2, bpm: 120 });
    p = addTrack(p, 'A', 't1');
    p = setTrackSample(setRoot(p, 't1', 60), 't1', 's1');
    for (const s of [0, 4, 8, 12, 16]) p = addNote(p, 't1', { midi: 60, start: s, length: 1 });
    e.setProject(p);
    e.setSample('s1', new Float32Array(44100), 44100);
    await e.play();
    const before = log.entries().filter((x) => x.scope === 'audio.engine' && x.message.includes('stale')).length;
    f.state.time = 5.0;
    timers.splice(0).forEach((fn) => fn());
    e.pause();
    const warns = log.entries().filter((x) => x.scope === 'audio.engine' && x.message.includes('stale')).slice(before);
    expect(warns).toHaveLength(1);
    expect((warns[0]!.data as { count: number }).count).toBeGreaterThan(1);
    expect((warns[0]!.data as { maxLateBy: number }).maxLateBy).toBeGreaterThan(3);
  });

  it('replacing a sample invalidates its buffer', async () => {
    const f = fakeCtx();
    const e = createEngine({ createContext: f.mk });
    e.setProject(proj());
    e.setSample('s1', new Float32Array(100), 44100);
    await e.audition('t1', 60);
    e.setSample('s1', new Float32Array(200), 44100);
    await e.audition('t1', 60);
    expect(f.buffers.map((b) => b.len)).toEqual([100, 200]);
  });
});

it('applies saved sample envelopes to both scheduled notes and auditions',async()=>{
 const f=fakeCtx(),e=createEngine({createContext:f.mk,setTimer:()=>0,clearTimer:()=>{}});
 const p=proj();p.tracks[0]!.sampleControls={attack:.2,release:.4};e.setProject(p);e.setSample('s1',new Float32Array(44100*3),44100);
 await e.play();expect(f.started[0]!.until-f.started[0]!.when).toBeCloseTo(.65);
 e.pause();p.tracks[0]!.sampleControls={attack:.1,release:.2};e.setProject(p);await e.audition('t1',60,127,.3);expect(f.started.at(-1)!.until-f.started.at(-1)!.when).toBeCloseTo(.5);
});

it('previews a shaped sample with its release fading before the recorded sound ends',async()=>{
 const f=fakeCtx(),e=createEngine({createContext:f.mk});await e.previewSource(new Float32Array(44100*3),44100,{attack:.2,release:.4});expect(f.started[0]!.until).toBeCloseTo(3);
});
it('song mode respects placements and stops when arrangement is edited',async()=>{
 const f=fakeCtx(),callbacks=new Set<()=>void>(),e=createEngine({createContext:f.mk,setTimer:fn=>{callbacks.add(fn);return fn;},clearTimer:h=>callbacks.delete(h as ()=>void)});
 const p=proj();p.arrangement={blocks:[{id:'a',trackId:'t1',startBar:3}]};e.setProject(p);e.setSample('s1',new Float32Array(44100),44100);e.setPlaybackMode('song');await e.play();expect(f.started).toHaveLength(0);
 f.state.time=4;for(const cb of [...callbacks])cb();expect(f.started).toHaveLength(1);expect(f.started[0]!.when).toBeCloseTo(4.05);
 e.setProject({...p,arrangement:{...p.arrangement,blocks:[]}});expect(e.isPlaying).toBe(false);e.setPlaybackMode('pattern');await e.play();expect(f.started).toHaveLength(2);
});

describe('engine trim',()=>{
 const lengths=(f:ReturnType<typeof fakeCtx>)=>f.buffers.map(b=>b.len);
 it('plays a legacy track without trim in full',async()=>{
  const f=fakeCtx(),e=createEngine({createContext:f.mk});e.setProject(proj());e.setSample('s1',new Float32Array(44100*3),44100);
  await e.audition('t1',60,100,.3);expect(lengths(f)).toEqual([44100*3]);
 });
 it('builds the buffer from the trimmed region and rebuilds when the trim changes',async()=>{
  const f=fakeCtx(),e=createEngine({createContext:f.mk});const p=proj();p.tracks[0]!.trim={start:.5,end:1.5};
  e.setProject(p);e.setSample('s1',new Float32Array(44100*3),44100);
  await e.audition('t1',60,100,.3);expect(lengths(f)).toEqual([44100]);
  await e.audition('t1',60,100,.3);expect(lengths(f)).toEqual([44100]);
  const q=structuredClone(p);q.tracks[0]!.trim={start:0,end:.5};e.setProject(q);
  await e.audition('t1',60,100,.3);expect(lengths(f)).toEqual([44100,22050]);
  const r=structuredClone(p);delete r.tracks[0]!.trim;e.setProject(r);
  await e.audition('t1',60,100,.3);expect(lengths(f).at(-1)).toBe(44100*3);
  expect(e.hasSample('s1')).toBe(true);
 });
 it('fades the cut edges',async()=>{
  const f=fakeCtx(),e=createEngine({createContext:f.mk});const p=proj();p.tracks[0]!.trim={start:.5,end:1.5};
  e.setProject(p);e.setSample('s1',new Float32Array(44100*3).fill(1),44100);await e.audition('t1',60,100,.3);
  const d=f.buffers[0]!.data!;expect(d[0]).toBe(0);expect(d[d.length-1]).toBe(0);expect(d[22050]).toBe(1);
 });
});
