import {it,expect,vi} from 'vitest';import {readFileSync} from 'node:fs';import {normalizeReverbSettings,normalizeEqSettings,makeBand} from './model';
it('a failed algorithm replacement preserves the working Dragonfly instance',async()=>{
 vi.resetModules();let C:any;const messages:any[]=[];vi.stubGlobal('sampleRate',48000);vi.stubGlobal('AudioWorkletProcessor',class {port={onmessage:null as any,postMessage:(m:any)=>messages.push(m)};});vi.stubGlobal('registerProcessor',(name:string,c:any)=>{if(name==='sa3-reverb')C=c;});await import('./processor');const module=new WebAssembly.Module(readFileSync('public/dragonfly/hall.wasm')),mix=normalizeReverbSettings({wet:1});const p=new C({processorOptions:{reverb:mix,module,algorithm:'hall'}});const l=new Float32Array(128),r=new Float32Array(128),outL=new Float32Array(128),outR=new Float32Array(128);l[0]=1;p.process([[l,r]],[[outL,outR]]);p.port.onmessage({data:{type:'settings',reverb:{...mix,algorithm:'plate'}}});await p.port.onmessage({data:{type:'module',bytes:new Uint8Array([0,97,115,109,1,0,0,0]).buffer,algorithm:'plate'}});expect(messages.some(m=>m.type==='error')).toBe(true);l.fill(0);expect(()=>{for(let i=0;i<50;i++)p.process([[l,r]],[[outL,outR]]);}).not.toThrow();expect(outL.every(Number.isFinite)).toBe(true);vi.unstubAllGlobals();
});
it('bypassed reverb does not resume a frozen tail when enabled again',async()=>{
 vi.resetModules();let C:any;vi.stubGlobal('sampleRate',48000);vi.stubGlobal('AudioWorkletProcessor',class {port={onmessage:null as any,postMessage(){}};});vi.stubGlobal('registerProcessor',(name:string,c:any)=>{if(name==='sa3-reverb')C=c;});await import('./processor');const module=new WebAssembly.Module(readFileSync('public/dragonfly/hall.wasm')),mix=normalizeReverbSettings({wet:1});const p=new C({processorOptions:{reverb:mix,module,algorithm:'hall'}}),l=new Float32Array(128),r=new Float32Array(128),ol=new Float32Array(128),or=new Float32Array(128);l[0]=1;for(let i=0;i<100;i++){p.process([[l,r]],[[ol,or]]);l.fill(0);}mix.bypass=true;p.port.onmessage({data:{type:'settings',reverb:structuredClone(mix)}});for(let i=0;i<500;i++)p.process([[l,r]],[[ol,or]]);mix.bypass=false;p.port.onmessage({data:{type:'settings',reverb:mix}});let peak=0;for(let i=0;i<100;i++){p.process([[l,r]],[[ol,or]]);for(const x of ol)peak=Math.max(peak,Math.abs(x));}expect(peak).toBeLessThan(1e-6);vi.unstubAllGlobals();
});
it('a module message carries wasm bytes, compiled inside the worklet, and yields a reverb tail',async()=>{
 vi.resetModules();let C:any;const messages:any[]=[];vi.stubGlobal('sampleRate',48000);vi.stubGlobal('AudioWorkletProcessor',class {port={onmessage:null as any,postMessage:(m:any)=>messages.push(m)};});vi.stubGlobal('registerProcessor',(name:string,c:any)=>{if(name==='sa3-reverb')C=c;});await import('./processor');
 const bytes=Uint8Array.from(readFileSync('public/dragonfly/hall.wasm')).buffer,mix=normalizeReverbSettings({wet:1});const p=new C({processorOptions:{reverb:mix}}),l=new Float32Array(128),r=new Float32Array(128),ol=new Float32Array(128),or=new Float32Array(128);
 await p.port.onmessage({data:{type:'module',bytes,algorithm:'hall'}});expect(messages.filter(m=>m.type==='ready')).toEqual([{type:'ready',algorithm:'hall'}]);expect(messages.some(m=>m.type==='error')).toBe(false);
 l[0]=1;let tail=0;for(let i=0;i<200;i++){p.process([[l,r]],[[ol,or]]);l.fill(0);if(i>60)for(const x of ol)tail+=x*x;}expect(tail).toBeGreaterThan(1e-8);vi.unstubAllGlobals();
});

async function loadEq(){vi.resetModules();let C:any;vi.stubGlobal('sampleRate',48000);vi.stubGlobal('AudioWorkletProcessor',class {port={onmessage:null as any,postMessage(){}};});vi.stubGlobal('registerProcessor',(name:string,c:any)=>{if(name==='sa3-eq')C=c;});await import('./processor');return C;}
const tone=(n:number,f=1000)=>Float32Array.from({length:n},(_,i)=>.1*Math.sin(2*Math.PI*f*i/48000));
function run(p:any,input:Float32Array){const out=new Float32Array(input.length),r=new Float32Array(128);for(let i=0;i<input.length;i+=128){const l=input.slice(i,i+128),o=new Float32Array(128);p.process([[l,l]],[[o,r]]);out.set(o.subarray(0,input.length-i),i);}return out;}
it('an EQ worklet with bypass on and a trim returns its input unchanged',async()=>{
 const C=await loadEq(),eq=normalizeEqSettings({bypass:true,trimDb:12,bands:[{...makeBand('a'),gain:12}]}),p=new C({processorOptions:{eq}}),x=tone(4800),y=run(p,x);let worst=0;for(let i=0;i<x.length;i++)worst=Math.max(worst,Math.abs(x[i]!-y[i]!));expect(worst).toBe(0);vi.unstubAllGlobals();
});
it('an EQ worklet applies a +12 dB bell after a settings message and ends band listening',async()=>{
 const C=await loadEq(),p=new C(),x=tone(48000);p.port.onmessage({data:{type:'settings',eq:normalizeEqSettings({bands:[{...makeBand('a'),gain:12,q:1}]})}});const y=run(p,x);let a=0,c=0;for(let i=24000;i<48000;i++){a+=x[i]!**2;c+=y[i]!**2;}expect(10*Math.log10(c/a)).toBeCloseTo(12,1);vi.unstubAllGlobals();
});

it('returning to Hall cancels a pending Plate compilation and preserves the working Hall DSP',async()=>{
 vi.resetModules();let C:any;const messages:any[]=[];vi.stubGlobal('sampleRate',48000);vi.stubGlobal('AudioWorkletProcessor',class {port={onmessage:null as any,postMessage:(m:any)=>messages.push(m)};});vi.stubGlobal('registerProcessor',(name:string,c:any)=>{if(name==='sa3-reverb')C=c;});await import('./processor');
 const hall=new WebAssembly.Module(readFileSync('public/dragonfly/hall.wasm')),plate=new WebAssembly.Module(readFileSync('public/dragonfly/plate.wasm')),mix=normalizeReverbSettings({wet:1,algorithm:'hall'}),p=new C({processorOptions:{reverb:mix,module:hall,algorithm:'hall'}});const working=p.dsp;let resolve!:(module:WebAssembly.Module)=>void;const compile=vi.spyOn(WebAssembly,'compile').mockImplementation(()=>new Promise(r=>resolve=r));
 p.port.onmessage({data:{type:'settings',reverb:{...mix,algorithm:'plate'}}});const pending=p.port.onmessage({data:{type:'module',bytes:new ArrayBuffer(0),algorithm:'plate'}});p.port.onmessage({data:{type:'settings',reverb:{...mix,algorithm:'hall'}}});resolve(plate);await pending;expect(p.dsp).toBe(working);expect(messages.some(m=>m.type==='ready'&&m.algorithm==='plate')).toBe(false);compile.mockRestore();vi.unstubAllGlobals();
});

it('the meter worklet stops posting while its input stays silent and resumes with signal',async()=>{
 vi.resetModules();let C:any;const messages:any[]=[];vi.stubGlobal('sampleRate',48000);vi.stubGlobal('AudioWorkletProcessor',class {port={onmessage:null as any,postMessage:(m:any)=>messages.push(m)};});vi.stubGlobal('registerProcessor',(name:string,c:any)=>{if(name==='sa3-meter')C=c;});
 await import('./processor');const p=new C(),silent=new Float32Array(128),loud=new Float32Array(128).fill(.5),out=[new Float32Array(128),new Float32Array(128)];
 for(let i=0;i<1000;i++)p.process([[silent,silent]],[out]);expect(messages.length).toBeLessThanOrEqual(1);
 const before=messages.length;for(let i=0;i<200;i++)p.process([[loud,loud]],[out]);expect(messages.length).toBeGreaterThan(before+5);
 expect(messages.at(-1).peak[0]).toBeCloseTo(.5);vi.unstubAllGlobals();
});
it('clearing a delay prevents fading source audio from refilling its tail',async()=>{
 vi.resetModules();let C:any;
 vi.stubGlobal('sampleRate',48000);
 vi.stubGlobal('AudioWorkletProcessor',class {port={onmessage:null as any,postMessage(){}};});
 vi.stubGlobal('registerProcessor',(name:string,c:any)=>{if(name==='sa3-fx-delay')C=c;});
 try{
  await import('./processor');
  const p=new C({processorOptions:{settings:{sync:0,time:50,feedback:90,tone:20000,mix:100}}});
  run(p,new Float32Array(256).fill(.2));
  p.port.onmessage({data:{type:'clear'}});
  const fading=new Float32Array(48000);fading.fill(.1,0,240);
  const y=run(p,fading);
  expect(y.every(v=>v===0)).toBe(true);
 }finally{vi.unstubAllGlobals();}
});
