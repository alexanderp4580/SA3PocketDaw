<script lang="ts">
  import { onDestroy, onMount, untrack } from 'svelte';
  import { ui, notify, setPeaks, refreshModelCards, refreshKeyState } from '../appState.svelte';
  import { engine, generation, projectStore } from '../services';
  import { CLOUD_MODEL_LABEL, MODEL_LABELS, buildPrompt, randomSeed } from '../../gen/prompt';
  import { editField, resetField, startField, syncField } from '../../gen/promptField';
  import { MODEL_IDS, type GenerateParams, type ModelId } from '../../gen/protocol';
  import { CLOUD_CREDITS, CLOUD_STAGE, generateCloud } from '../../gen/cloud';
  import { CLOUD_MAX_STEPS, clampSteps, stepLimits } from '../../gen/steps';
  import { SOURCE_LABELS, cloudBlockedReason, effectiveSource, loadSource, saveSource, type GenSource } from '../../gen/source';
  import { loadApiKey } from '../../store/apiKey';
  import { recordGeneration } from '../../log';
  import { INSTRUMENTS,CHARACTERS,ATTACKS,BEHAVIORS,instrumentDefaults,instrumentPrompt,type InstrumentId } from '../../gen/instrumentSelections';
  import { generationPresets,generationHint,lengthHint,loadModeSettings,saveModeSettings,type GenerationMode } from '../../gen/mode';
  import { DEVICE_LABELS, effectiveDevice, generateWithFallback, gpuAllowed, loadDevice, saveDevice, type GenDevice } from '../../gen/device';
  import { CLOUD_MAX_SECONDS, CLOUD_MIN_SECONDS, MAX_SECONDS, MIN_SECONDS, clampSeconds, parseSeconds, stepSeconds, type LengthLimit } from '../../gen/length';
  import { midiToName } from '../../audio/pitch';
  import { formatBytes, formatElapsed, modelHint, peaksOf } from '../format';
  import { prepareGeneration, useGeneration, loopNotice, tweakDraft, tweakSampleDraft, trimDraft, mergeTrimmed, InstrumentAnalysisError, type GeneratedDraft } from '../generate';
  import {applyTrim,fullTrim,resolveTrim,type Trim} from '../../audio/trim';
  import {trimmedLoop} from '../../audio/loopPoints';
  import {createLatestRunner} from '../latestRunner';
  import type {ChopView} from '../TrimControl.svelte';
  import { copyReport } from '../report';
  import Sheet from '../Sheet.svelte';
  import SampleControlsPanel from '../SampleControlsPanel.svelte';
  import {resolveSampleControls,type SampleControls} from '../../audio/sampleControls';
  import InstrumentControlsPanel from '../InstrumentControlsPanel.svelte';
  import {resolveControls,type InstrumentControls} from '../../audio/instrument/controls';
  import Waveform from '../Waveform.svelte';

  let { trackId, onclose, onuse, onmodels, onpreset }: { trackId: string|null; onclose: () => void;onuse?:(id:string)=>void;onmodels:()=>void;onpreset?:()=>void } = $props();

  type Phase = 'form' | 'running' | 'done' | 'error';
  let phase = $state<Phase>('form');
  let sourceReady=$state(untrack(()=>trackId===null));
  let prompt = $state('');
  let model = $state<ModelId>('small-music');
  let mode=$state<GenerationMode>('sample');
  let instrument=$state(instrumentDefaults('synth'));
  const suggestedInstrumentPrompt=$derived(instrumentPrompt(instrument,model));
  let instrumentField=$state(startField(instrumentPrompt(instrumentDefaults('synth'),'small-music')));
  $effect(()=>{const next=syncField(instrumentField,suggestedInstrumentPrompt);if(next!==instrumentField)instrumentField=next;});
  const store = typeof localStorage === 'undefined' ? null : localStorage;
  let seconds = $state(loadModeSettings(store,'sample').seconds);
  let secondsText = $state(String(loadModeSettings(store,'sample').seconds));
  const LONG_SECONDS = 5;
  let steps = $state(loadModeSettings(store,'sample').steps);
  let cloudSteps = $state(CLOUD_MAX_STEPS);
  let storedSource = $state<GenSource>(loadSource(store));
  const hasKey = $derived(ui.hasKey);
  const source = $derived(effectiveSource(storedSource,hasKey));
  const cloud = $derived(source==='cloud');
  const limit = $derived<LengthLimit>(cloud?'cloud':model);
  const shownSteps = $derived(cloud?cloudSteps:steps);
  const stepRange = $derived(stepLimits(cloud));
  let runCloud = $state(false);
  let usedCloud = $state(false);
  let instrumentWarning=$state('');
  let seed = $state(randomSeed());
  const DEVICES: GenDevice[] = ['webgpu', 'cpu'];
  const gpuOk = $derived(gpuAllowed(typeof navigator !== 'undefined' && !!(navigator as Navigator).gpu, ui.compat ? ui.compat.gpuUsable : null));
  let storedDevice = $state<GenDevice>(loadDevice(store));
  const device = $derived(effectiveDevice(storedDevice, gpuOk));
  let fallbackNote = $state('');
  let usedDevice = $state<GenDevice>('webgpu');
  const cards = $derived(ui.modelCards);
  const anyInstalled = $derived(cards.some(c=>c.available&&c.status==='installed'));
  let stage = $state('');
  let fraction = $state(0);
  let message = $state('');
  let startedAt = $state(0);
  let elapsed = $state(0);
  let errorText = $state('');
  let result = $state.raw<GeneratedDraft | null>(null);
  let saving=$state(false);
  let controller: AbortController | null = null;
  let timer: ReturnType<typeof setInterval> | undefined;

  const track = $derived(ui.project?.tracks.find((t) => t.id === trackId) ?? null);
  const selected = $derived(cards.find((c) => c.id === model)!);
  const usable = $derived(selected.available && selected.status === 'installed');
  const canGenerate = $derived(sourceReady && (cloud || usable) && (mode==='instrument'?instrumentField.text.trim().length>0:prompt.trim().length>0));
  const samplePromptSent = $derived(prompt.trim()&&mode!=='instrument'?buildPrompt(prompt,model,mode):'');
  const draftNotice = $derived(result?loopNotice(result):'');
  const draftControls=$derived(resolveControls(result?.instrumentControls,result?.record.instrument?.dynamics??'sustain'));
  const draftSampleControls=$derived(resolveSampleControls(result?.sampleControls));
  const peaks = $derived(result ? peaksOf(result.pcm, 96) : undefined);
  let liveTrim=$state<Trim|null>(null),chopBusy=$state(false),chopError=$state('');
  const draftDuration=$derived(result?result.pcm.length/result.sampleRate:0);
  const draftTrim=$derived(liveTrim??resolveTrim(result?.trim,draftDuration));
  const chop=$derived<ChopView>({duration:draftDuration,peaks,pcm:result?.pcm,sampleRate:result?.sampleRate,trim:draftTrim,busy:chopBusy,error:chopError});
  const commitChop=createLatestRunner<Trim>(async t=>{const base=result;if(!base)return;const next=await trimDraft(base,t);result=mergeTrimmed(result,base,next)??result;},{onBusy:b=>chopBusy=b,onError:e=>{chopError=e.message;liveTrim=null;}});
  function chopInput(t:Trim){liveTrim=t;chopError='';}
  function chopCommit(t:Trim){chopError='';commitChop(t);}
  function chopReset(){const t=fullTrim(draftDuration);liveTrim=t;chopCommit(t);}

  $effect(()=>{
    const first=cards.find(c=>c.available&&c.status==='installed');
    if(first&&!usable){model=first.id;setSeconds(seconds);}
  });
  async function restoreSource(){
    if(!track?.sampleId)return;
    const source=await projectStore.getSample(track.sampleId);
    if(!source)return;
    mode=source.instrument?'instrument':source.meta.mode==='loop'?'loop':'sample';
    if(source.instrument)instrument={...instrument,behavior:source.instrument.dynamics};
    if(source.meta.model&&cards.some(c=>c.id===source.meta.model&&c.available&&c.status==='installed'))model=source.meta.model as ModelId;
    if(source.meta.seconds!==undefined)setSeconds(source.meta.seconds);
    if(source.meta.steps!==undefined)steps=clampSteps(source.meta.steps,false);
    if(source.meta.prompt){if(mode==='instrument')instrumentField=editField(instrumentField,source.meta.prompt,suggestedInstrumentPrompt);else prompt=source.meta.prompt;}
  }
  onMount(()=>{refreshKeyState();void refreshModelCards();void restoreSource().catch(e=>notify(String(e))).finally(()=>sourceReady=true);});
  onDestroy(() => {clearInterval(timer);engine.stopPreview();});

  function pickModel(id: ModelId) {
    if(!cards.some(c=>c.id===id&&c.available&&c.status==='installed'))return;
    model = id;
    setSeconds(seconds);
  }

  function setSeconds(v: number) {
    seconds = clampSeconds(v, limit);
    secondsText = String(seconds);
    persistSettings();
  }
  function persistSettings(){if(!cloud)saveModeSettings(store,mode,{seconds,steps});}
  function bumpSteps(d:number){if(cloud)cloudSteps=clampSteps(cloudSteps+d,true);else steps=clampSteps(steps+d,false);}
  function pickSource(next:GenSource){if(next==='cloud'&&!hasKey)return;storedSource=next;saveSource(store,next);setSeconds(seconds);}
  function pickMode(next:GenerationMode){persistSettings();mode=next;const saved=loadModeSettings(store,next);steps=saved.steps;setSeconds(saved.seconds);}
  function pickInstrument(id:InstrumentId){instrument=instrumentDefaults(id);}
  function commitSecondsText() {
    const v = parseSeconds(secondsText);
    setSeconds(v === null ? seconds : v);
  }

  async function run() {
    if (!canGenerate || (trackId!==null&&!track)) return;
    commitSecondsText();
    persistSettings();
    const raw=mode==='instrument'?instrumentField.text.trim():prompt.trim();
    const dynamics=instrument.behavior;
    const promptModel: ModelId = cloud ? 'medium' : model;
    runCloud = cloud;
    const params: GenerateParams = { mode,model:promptModel,device, prompt: mode==='instrument'?raw:buildPrompt(raw,promptModel,mode), seconds, steps: cloud?cloudSteps:steps, seed };
    instrumentWarning='';
    engine.stopPreview();result=null;liveTrim=null;chopError='';
    phase = 'running';
    stage = 'Starting';
    fraction = 0;
    message = '';
    startedAt = performance.now();
    elapsed = 0;
    clearInterval(timer);
    timer = setInterval(() => (elapsed = performance.now() - startedAt), 100);
    fallbackNote = '';
    controller = new AbortController();
    try {
      await engine.unlock();
      const signal = controller.signal;
      let out;
      let ran: GenDevice = device;
      if (runCloud) {
        const key = loadApiKey(store);
        if (!key) throw new Error('No Stability AI key is saved. Add one on the Models screen.');
        stage = CLOUD_STAGE;
        message = 'Sending the request to Stability AI';
        out = await generateCloud({ prompt: params.prompt, seconds, steps: params.steps, seed }, key, { signal, onProgress: (e) => { stage = e.stage; message = e.message; } });
        const total = out.timings.find((t) => t.name === 'total');
        recordGeneration({ id: Date.now(), at: new Date().toISOString(), model: 'stable-audio-3', mode: params.mode ?? 'sample', prompt: params.prompt, seconds, steps: params.steps, seed, device: 'cloud', totalMs: total ? total.endMs - total.startMs : null, stages: out.timings, stats: out.stats });
      } else {
      ({ output: out, device: ran } = await generateWithFallback(
        (p) =>
          generation.generate(p, {
            signal,
            onProgress: (e) => {
              stage = e.stage;
              fraction = e.fraction;
              message = e.message;
            },
          }),
        params,
        {
          signal,
          onFallback: (why) => {
            fallbackNote = `The GPU run failed (${why}). Retrying on the CPU, which is slower. Cancel to stop.`;
            stage = 'Retrying on CPU';
            fraction = 0;
            message = '';
          },
        },
      ));
      }
      usedDevice = ran;
      usedCloud = runCloud;
      try {
        result = await prepareGeneration(params,raw,out,{signal:controller.signal,dynamics,cloud:runCloud,onAnalysis:f=>{stage='Creating instrument';fraction=f;message='Measuring the note and extracting its evolving tone.';}});
      } catch (e) {
        if (!(e instanceof InstrumentAnalysisError)) throw e;
        result = await prepareGeneration({...params,mode:'sample'},raw,out,{signal:controller.signal,cloud:runCloud});
        instrumentWarning=e.message;
      }
      phase = 'done';
    } catch (e) {
      const err = e as { code?: string; message?: string };
      if (err.code === 'cancelled') {
        phase = 'form';
        notify('Generation cancelled');
      } else {
        errorText = err.message ?? String(e);
        phase = 'error';
      }
    } finally {
      clearInterval(timer);
      elapsed = performance.now() - startedAt;
      controller = null;
    }
  }

  function pickDevice(next: GenDevice) {
    if (next === 'webgpu' && !gpuOk) return;
    storedDevice = next;
    saveDevice(store, next);
  }

  function regenerate() {
    seed = randomSeed();
    void run();
  }
  function shift(d:number){if(result)result={...result,rootMidi:Math.max(0,Math.min(127,result.rootMidi+d))};}
  function tweak(patch:Partial<InstrumentControls>){if(!result||saving)return;result=tweakDraft(result,patch);engine.setPreviewControls(draftControls);}
  function tweakSample(patch:Partial<SampleControls>){if(result&&!saving)result=tweakSampleDraft(result,patch);}
  function resetTweaks(){if(result?.record.instrument)tweak(resolveControls(undefined,result.record.instrument.dynamics));}
  async function preview(){if(!result)return;try{if(result.record.instrument)await engine.previewInstrument(result.record.instrument,57,result.instrumentControls);else await engine.previewSource(applyTrim(result.pcm,result.sampleRate,result.trim),result.sampleRate,draftSampleControls,trimmedLoop(result.record.loop,result.trim,result.pcm.length,result.sampleRate));}catch(e){notify(String(e));}}
  async function use(){if(!result||saving)return;saving=true;try{engine.stopPreview();const used=await useGeneration({store:projectStore,engine},trackId,result);setPeaks(used.sampleId,used.pcm);onclose();onuse?.(used.trackId);}catch(e){notify(String(e));}finally{saving=false;}}
  async function copy() {
    notify((await copyReport()) ? 'Report copied' : 'Copy failed');
  }
</script>

<Sheet title="✦ Generate" sub={track ? `For ${track.name}` : 'New track · created when you choose Use'} tall onclose={onclose} closable={phase !== 'running'&&!saving}>
  {#if phase === 'form' || phase === 'error'}
    {#if onpreset}<div class="btnrow presetrow"><button class="btn" aria-label="Choose an instrument preset" onclick={onpreset}>♪ Instruments</button></div><div class="note">Sampled pianos and electric pianos that need no generating.</div>{/if}
    {#if !ui.modelsReady||!sourceReady}<p class="note">{!ui.modelsReady?'Checking downloaded models…':'Loading sound…'}</p>
    {:else if !anyInstalled && !hasKey}<div class="btnrow"><button class="btn sa3" aria-label="Open models" onclick={onmodels}>Download models</button></div><div class="note">Or add a Stability AI key on the Models screen to generate in the cloud.</div>
    {:else}
    {#if phase === 'error'}
      <div class="card bad" role="alert">
        <div class="row"><b class="bad">Generation failed</b></div>
        <div class="note">{errorText}</div>
        <div class="btnrow"><button class="btn" onclick={copy}>Copy report</button></div>
      </div>
    {/if}
    <div class="st">Source</div>
    <div class="seg">
      {#each ['device','cloud'] as const as src (src)}
        <button class="sg" class:sa3on={source===src} aria-pressed={source===src} disabled={src==='cloud'&&!hasKey} onclick={()=>pickSource(src)}>{SOURCE_LABELS[src]}</button>
      {/each}
    </div>
    <div class="note">{!hasKey?cloudBlockedReason(false):cloud?'Cloud generation sends your prompt to Stability AI, needs a network connection and costs '+CLOUD_CREDITS+' credits per clip.':'On device runs the downloaded SA3 models on this phone.'}</div>
    {#if !cloud&&!anyInstalled}<div class="btnrow"><button class="btn sa3" aria-label="Open models" onclick={onmodels}>Download models</button></div>{/if}
    <div class="st">Sound type</div>
    <div class="seg"><button class="sg" class:sa3on={mode==='sample'} aria-pressed={mode==='sample'} onclick={()=>pickMode('sample')}>Sample</button><button class="sg" class:sa3on={mode==='instrument'} aria-pressed={mode==='instrument'} onclick={()=>pickMode('instrument')}>Instrument</button><button class="sg" class:sa3on={mode==='loop'} aria-pressed={mode==='loop'} onclick={()=>pickMode('loop')}>Looped</button></div>
    <div class="note">{mode==='sample'?'One-shot sounds such as kicks, snares and effects.':mode==='loop'?'One SA3 note kept as audio; its sustained part loops while a note is held.':'A tuned, playable instrument made from one SA3 note.'}</div>
    {#if mode!=='instrument'}
      <div class="st">Prompt</div>
      <textarea class="field promptbox" aria-label="Prompt" rows="2" placeholder={mode==='loop'?'e.g. warm analog pad':'e.g. deep punchy kick drum'} bind:value={prompt}></textarea>
      <div class="chips" style="margin-top:6px">
        {#each generationPresets(mode) as q (q.id)}
          <button class="chip" class:on={prompt===q.prompt} onclick={()=>{prompt=q.prompt;setSeconds(q.seconds);}}>{q.label}</button>
        {/each}
      </div>
      {#if samplePromptSent}<div class="note sent">Sent to the model: {samplePromptSent}</div>{/if}
      <div class="note" style="margin-top:6px">{generationHint(mode)}</div>
    {:else}
      <div class="note" style="margin-top:8px">Choose the source sound SA3 will create. After generation, tweak playback and preview it before choosing Use.</div>
      <fieldset class="choices"><legend>Source instrument</legend><div class="options">
        {#each INSTRUMENTS as q (q.id)}<label class:on={instrument.instrument===q.id}><input type="radio" name="source-instrument" value={q.id} checked={instrument.instrument===q.id} onchange={()=>pickInstrument(q.id)} />{q.label}</label>{/each}
      </div></fieldset>
      <fieldset class="choices"><legend>Character</legend><div class="options">
        {#each CHARACTERS as q (q.id)}<label class:on={instrument.character===q.id}><input type="radio" name="source-character" value={q.id} bind:group={instrument.character} />{q.label}</label>{/each}
      </div></fieldset>
      <fieldset class="choices"><legend>Source attack</legend><div class="options">
        {#each ATTACKS as q (q.id)}<label class:on={instrument.attack===q.id}><input type="radio" name="source-attack" value={q.id} bind:group={instrument.attack} />{q.label}</label>{/each}
      </div></fieldset>
      <fieldset class="choices"><legend>Source note behavior</legend><div class="options">
        {#each BEHAVIORS as q (q.id)}<label class:on={instrument.behavior===q.id}><input type="radio" name="source-behavior" value={q.id} bind:group={instrument.behavior} />{q.label}</label>{/each}
      </div></fieldset>
      <div class="st">Prompt</div>
      <textarea class="field promptbox" aria-label="Prompt" rows="5" value={instrumentField.text} oninput={(e)=>{instrumentField=editField(instrumentField,e.currentTarget.value,suggestedInstrumentPrompt);}}></textarea>
      <div class="row" style="margin-top:6px"><span class="note grow">{instrumentField.edited?'Edited. The choices above no longer change this text.':'Follows the choices above. Edit it freely.'}</span><button class="btn fit" disabled={!instrumentField.edited} onclick={()=>{instrumentField=resetField(suggestedInstrumentPrompt);}}>Reset to suggested</button></div>
      <div class="note">Natural decay suits piano, guitar and bells. Hold tone suits synths and pads. The selected behavior also sets the instrument's initial playback behavior.</div>
    {/if}

    {#if !cloud}
    <div class="st">Model</div>
    <div class="seg">
      {#each MODEL_IDS as id (id)}
        <button class="sg" class:sa3on={model === id} disabled={!cards.some(c=>c.id===id&&c.available&&c.status==='installed')} aria-pressed={model === id} onclick={() => pickModel(id)}>{MODEL_LABELS[id]}</button>
      {/each}
    </div>
    <div class="modelline">
      {#each [selected] as c (c.id)}
        <span>{c.available ? (c.status === 'installed' ? 'installed' : c.status === 'partial' ? 'partly downloaded' : 'not installed') : 'not available'}{c.available ? ` · ${formatBytes(c.bytes)}` : ''}</span>
      {/each}
      {#if modelHint(selected)}<span class="warn">{selected.available ? modelHint(selected) : 'not available in this build'}</span>{/if}
    </div>
    {#if model === 'medium'}
      <div class="note warn" style="margin-top:6px">Medium may be slow or fail on phones.</div>
    {/if}
    {#if mode!=='sample'&&model==='small-sfx'}<div class="note warn">Small Music or Medium is better suited to single instrument notes.</div>{/if}

    <div class="st">Processor</div>
    <div class="seg">
      {#each DEVICES as d (d)}
        <button class="sg" class:sa3on={device === d} aria-pressed={device === d} disabled={d === 'webgpu' && !gpuOk} onclick={() => pickDevice(d)}>{DEVICE_LABELS[d]}</button>
      {/each}
    </div>
    <div class="note">{!gpuOk ? 'WebGPU is not usable on this device, so generation runs on the CPU (WASM): slower than the GPU and heavier on memory. Speed and memory on phones: to check.' : device === 'cpu' ? 'CPU runs every stage in WASM, slower than the GPU (Steam Deck, 1 s clip, one thread: about 2.5 times; phone speed to check). Uses more memory (phone memory to check).' : 'GPU is fastest. If a GPU run fails, it is retried once on the CPU automatically.'}</div>
    {/if}

    <div class="st">Length</div>
    <div class="stepper">
      <button class="btn fit" aria-label="Shorter by 0.25 seconds" disabled={seconds <= (cloud ? CLOUD_MIN_SECONDS : MIN_SECONDS)} onclick={() => setSeconds(stepSeconds(seconds, -1, limit))}>−</button>
      <span class="secfield">
        <input class="field" aria-label="Length in seconds" type="text" inputmode="decimal" bind:value={secondsText} onblur={commitSecondsText} onkeydown={(e) => e.key === 'Enter' && commitSecondsText()} />
        <em>s</em>
      </span>
      <button class="btn fit" aria-label="Longer by 0.25 seconds" disabled={seconds >= (cloud ? CLOUD_MAX_SECONDS : MAX_SECONDS[model])} onclick={() => setSeconds(stepSeconds(seconds, 1, limit))}>+</button>
    </div>
    {#if cloud}<div class="note">{CLOUD_MIN_SECONDS} to {CLOUD_MAX_SECONDS} s in 0.25 s steps; type any value such as 1.25. The cloud service accepts clips of at least 1 s.</div>
    {:else}<div class="note">{MIN_SECONDS} to {MAX_SECONDS[model]} s in 0.25 s steps; type any value such as 1.25. {MAX_SECONDS[model]} s is the longest tested here (the model conditioner itself accepts up to 384 s).</div>{/if}
    <div class="note">{lengthHint(mode)}</div>
    {#if seconds > LONG_SECONDS && !cloud}
      <div class="note warn" role="note">Long clips take much longer and use more memory on phones. User-reported on a Pixel: Small 2 s about 180 s, 10 s about 400 s.</div>
    {/if}

    <div class="st">Steps</div>
    <div class="stepper">
      <button class="btn fit" aria-label="Fewer steps" disabled={shownSteps <= stepRange.min} onclick={() => bumpSteps(-1)}>−</button>
      <b>{shownSteps}</b>
      <button class="btn fit" aria-label="More steps" disabled={shownSteps >= stepRange.max} onclick={() => bumpSteps(1)}>+</button>
    </div>
    <div class="note">{stepRange.min} to {stepRange.max} steps. {cloud ? `${CLOUD_MAX_STEPS} is the most the cloud accepts.` : 'More steps take proportionally longer.'}</div>

    <div class="st">Seed</div>
    <div class="row">
      <input class="field grow" aria-label="Seed" type="number" inputmode="numeric" bind:value={seed} />
      <button class="btn fit" onclick={() => (seed = randomSeed())}>Randomize</button>
    </div>

    {#if cloud}<div class="note">{CLOUD_CREDITS} credits per generation.</div>{/if}
    <div class="btnrow"><button class="btn sa3" disabled={!canGenerate} onclick={run}>✦ Generate{cloud ? ` · ${CLOUD_CREDITS} credits` : ''}</button></div>
    {/if}
  {:else if phase === 'running'}
    <div class="card">
      <div class="row"><b class="grow">{stage}</b><span class="note">{formatElapsed(elapsed)}</span></div>
      {#if runCloud}<div class="bar" role="progressbar" aria-label="Generating in the cloud"><i class="indeterminate"></i></div>
      {:else}<div class="bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow={Math.round(fraction * 100)}><i style="width:{Math.round(fraction * 100)}%"></i></div>{/if}
      <div class="note">{message}</div>
      {#if fallbackNote}<div class="note warn" role="status">{fallbackNote}</div>{/if}
      {#if model === 'medium' && !runCloud}<div class="note warn">Medium may be slow or fail on phones.</div>{/if}
      <div class="btnrow"><button class="btn danger" onclick={() => controller?.abort()}>Cancel</button></div>
      <div class="note" style="margin-top:8px">{runCloud ? 'Cancel stops waiting for the result.' : 'A model call that is already running finishes its current step before generation stops.'}</div>
    </div>
  {:else if result}
    {#if instrumentWarning}
      <div class="card conversion-warning" role="status">
        <b class="warn">Sound ready as a sample</b>
        <div class="note">Instrument conversion was unavailable. You can still preview, tweak and use this sound as a sample.</div>
        <div class="note">{instrumentWarning}</div>
      </div>
    {/if}
    <div class="card">
      <div class="resultwave"><Waveform {peaks} /></div>
      <div class="row" style="margin-top:10px">
        {#if result.mode==='instrument'}<span class="st grow" style="margin:0">Instrument ready</span><b class="rootname">Automatically tuned</b>{:else}
        <span class="st grow" style="margin:0">Detected root</span>
        <button class="btn fit rootbtn" aria-label="Root down one semitone" onclick={() => shift(-1)}>−1</button>
        <b class="rootname">{midiToName(result.rootMidi)}</b>
        <button class="btn fit rootbtn" aria-label="Root up one semitone" onclick={() => shift(1)}>+1</button>
        {/if}
      </div>
      {#if draftNotice}<div class="note" style="margin-top:6px" class:warn={!draftNotice.startsWith('Loop ')} role="status">{draftNotice}</div>{/if}
      {#if result.lowConfidence}
        <div class="note warn" style="margin-top:6px">Low confidence. Defaulted to C4. Adjust the root with the buttons.</div>
      {/if}
      <div class="note" style="margin-top:6px">{#if usedCloud}Generated in {formatElapsed(elapsed)} with {CLOUD_MODEL_LABEL}.{:else}Generated in {formatElapsed(elapsed)} on the {DEVICE_LABELS[usedDevice]}.{fallbackNote ? ' The GPU run failed first, so this ran on the CPU.' : ''}{/if}</div>
      {#if result.record.instrument}<div class="st">Tweak instrument</div><div class="note">Press Preview to hear your settings. Use sound keeps them on the track.</div><InstrumentControlsPanel controls={draftControls} onchange={tweak} behaviorName="draft-behavior" disabled={saving} {chop} onchop={chopInput} onchopcommit={chopCommit} onchopreset={chopReset} /><div class="btnrow"><button class="btn" disabled={saving} onclick={resetTweaks}>Reset controls</button></div>{:else}<div class="st">Tweak sample</div><div class="note">Press Preview to hear your settings. Use sound keeps them on the track.</div><SampleControlsPanel controls={draftSampleControls} onchange={tweakSample} disabled={saving} {chop} onchop={chopInput} onchopcommit={chopCommit} onchopreset={chopReset} /><div class="btnrow"><button class="btn" disabled={saving} onclick={()=>tweakSample(resolveSampleControls())}>Reset controls</button></div>{/if}
      {#if result.mode==='instrument'}<div class="btnrow"><button class="btn" onclick={()=>result&&void engine.previewSource(result.pcm,result.sampleRate)}>Play source note</button></div>{/if}
      <p class="note">Preview this sound. Choose Use to replace the sound on this track.</p>
      <div class="btnrow"><button class="btn" disabled={saving||(!cloud&&!usable)} onclick={regenerate}>Regenerate</button><button class="btn" disabled={saving} onclick={onclose}>Discard</button></div>
    </div>
    <div class="draft-accept"><button class="btn" disabled={saving||chopBusy} onclick={preview}>▶ Preview {result.mode==='instrument'?'A3':instrumentWarning?'sample':''}</button><button class="btn pri" disabled={saving||chopBusy} onclick={use}>{saving?'Saving…':instrumentWarning?'Use sample':'Use sound'}</button></div>
  {/if}
</Sheet>

<style>
  .indeterminate { width: 40% !important; animation: slide 1.2s infinite ease-in-out; }
  @keyframes slide { 0% { margin-left: -40%; } 100% { margin-left: 100%; } }
  .conversion-warning{border:1px solid #d9ad4655;background:#d9ad4610;}.conversion-warning .note{margin-top:6px;}
  .draft-accept{display:flex;gap:8px;position:sticky;bottom:0;padding:10px 0 0;background:var(--panel);z-index:1;}.draft-accept .btn{min-width:0;flex:1;}.draft-accept .btn.pri{flex:1.3;}
  .choices {border:0;margin:14px 0 0;padding:0;min-width:0;}
  .choices legend {font-size:12px;font-weight:700;color:var(--dim);margin-bottom:6px;}
  .options {display:flex;flex-wrap:wrap;gap:6px;}
  .options label {display:flex;align-items:center;gap:6px;min-height:44px;padding:8px 12px;border-radius:10px;background:var(--panel2);border:1px solid transparent;font-size:13px;cursor:pointer;}
  .options label.on {background:var(--sa3bg);color:var(--sa3);border-color:var(--sa3);}
  .options input {accent-color:var(--sa3);margin:0;}
  .options label:focus-within {outline:2px solid var(--sa3);outline-offset:2px;}
  .promptbox {height:auto;display:block;padding:10px 14px;color:inherit;width:100%;box-sizing:border-box;resize:vertical;font:inherit;line-height:1.35;}
  .sent {overflow-wrap:anywhere;}
  .stepper { display: flex; align-items: center; gap: 10px; }
  .stepper b { flex: 1; text-align: center; font-size: 20px; }
  .stepper .btn { width: 56px; }
  .secfield { flex: 1; position: relative; }
  .secfield .field { text-align: center; font-size: 20px; font-weight: 700; padding-right: 28px; }
  .secfield em { position: absolute; right: 12px; top: 50%; transform: translateY(-50%); font-style: normal; color: var(--dim); }
  .resultwave { height: 72px; background: #0e1014; border-radius: 8px; padding: 4px; }
  .rootname { min-width: 3.2rem; text-align: center; font-size: 22px; color: var(--sa3); }
  .rootbtn { width: 56px; }
</style>
