import { describe, it, expect } from 'vitest';
import { IDBFactory } from 'fake-indexeddb';
import { createProjectStore, type StoredSample } from './projectStore';
import { createProject, addTrack, removeTrack, setTrackSample, renameProject, noteVelocity, addPlugin, updatePluginSettings, setPluginBypass, masterChain } from './projectModel';
import { MASTER_ID } from '../audio/mixer/plugins';

const sample = (n = 100): StoredSample => ({
  pcm: Float32Array.from({ length: n }, (_, i) => i / n),
  sampleRate: 44100,
  meta: { prompt: 'lead', model: 'small-music', seed: 1, steps: 8, seconds: 2, generatedAt: 123, detectedMidi: 60, confidence: 0.9 },
});

function setup() {
  const idb = new IDBFactory();
  const timers: Array<{ fn: () => void; id: number }> = [];
  let n = 0;
  const mk = () =>
    createProjectStore({
      idb,
      setTimer: (fn) => { timers.push({ fn, id: ++n }); return n; },
      clearTimer: (h) => { const i = timers.findIndex((t) => t.id === h); if (i >= 0) timers.splice(i, 1); },
    });
  return { idb, mk, timers };
}

describe('projectStore', () => {
  it('load returns null on empty db', async () => {
    const { mk } = setup();
    expect(await mk().load()).toBeNull();
  });

  it('debounces saves: one pending timer, flush writes the latest', async () => {
    const { mk, timers } = setup();
    const s = mk();
    let p = createProject({ name: 'one' });
    s.set(p);
    s.set(renameProject(p, 'two'));
    expect(timers).toHaveLength(1);
    await s.flush();
    expect(timers).toHaveLength(0);
    const again = mk();
    expect((await again.load())!.name).toBe('two');
  });

  it('timer firing saves', async () => {
    const { mk, timers } = setup();
    const s = mk();
    s.set(createProject({ name: 'x' }));
    timers[0]!.fn();
    await s.flush();
    expect((await mk().load())!.name).toBe('x');
  });

  it('round-trips project and samples across a new store instance', async () => {
    const { mk } = setup();
    const a = mk();
    let p = addTrack(createProject({ name: 'rt' }), 'Lead', 't1');
    await a.putSample('s1', sample());
    p = setTrackSample(p, 't1', 's1', 62);
    a.set(p);
    await a.flush();
    const b = mk();
    const loaded = await b.load();
    expect(loaded).toEqual(p);
    const got = await b.getSample('s1');
    expect(got!.sampleRate).toBe(44100);
    expect(got!.meta.detectedMidi).toBe(60);
    expect(got!.pcm).toBeInstanceOf(Float32Array);
    expect(Array.from(got!.pcm)).toEqual(Array.from(sample().pcm));
  });

  it('keeps the cloud source in sample meta and loads samples saved without one', async () => {
    const { mk } = setup();
    const a = mk();
    await a.putSample('old', sample());
    await a.putSample('cloud', { ...sample(), meta: { ...sample().meta, model: 'stable-audio-3', source: 'cloud' } });
    const b = mk();
    expect((await b.getSample('old'))!.meta.source).toBeUndefined();
    expect((await b.getSample('cloud'))!.meta.source).toBe('cloud');
  });

  it('keeps a loop with its sample, loads samples saved without one and drops a malformed one', async () => {
    const { mk } = setup();
    const a = mk();
    await a.putSample('old', sample());
    await a.putSample('loop', { ...sample(), loop: { start: 0.0005, end: 0.002 }, meta: { ...sample().meta, mode: 'loop' } });
    await a.putSample('bad', { ...sample(), loop: { start: 2, end: 1 } as never });
    const b = mk();
    expect((await b.getSample('old'))!.loop).toBeUndefined();
    expect((await b.getSample('loop'))!.loop).toEqual({ start: 0.0005, end: 0.002 });
    expect((await b.getSample('loop'))!.meta.mode).toBe('loop');
    expect((await b.getSample('bad'))!.loop).toBeUndefined();
  });

  it('loads notes saved without a velocity', async () => {
    const { mk } = setup();
    const a = mk();
    let p = addTrack(createProject(), 'Lead', 't1');
    p = { ...p, tracks: [{ ...p.tracks[0]!, notes: [{ id: 'n1', midi: 60, start: 0, length: 2 }] }] };
    a.set(p);
    await a.flush();
    const loaded = await mk().load();
    expect(loaded!.tracks[0]!.notes[0]).toEqual({ id: 'n1', midi: 60, start: 0, length: 2 });
    expect(noteVelocity(loaded!.tracks[0]!.notes[0]!)).toBe(96);
  });

  it('subscribe emits current immediately and on change, until unsubscribed', async () => {
    const { mk } = setup();
    const s = mk();
    const seen: Array<string | null> = [];
    const off = s.subscribe((p) => seen.push(p?.name ?? null));
    s.set(createProject({ name: 'a' }));
    off();
    s.set(createProject({ name: 'b' }));
    expect(seen).toEqual([null, 'a']);
  });

  it('removing a track deletes its orphaned sample', async () => {
    const { mk } = setup();
    const s = mk();
    let p = addTrack(addTrack(createProject(), 'A', 'ta'), 'B', 'tb');
    await s.putSample('sa', sample());
    await s.putSample('sb', sample());
    p = setTrackSample(setTrackSample(p, 'ta', 'sa'), 'tb', 'sb');
    s.set(p);
    s.set(removeTrack(p, 'ta'));
    await s.flush();
    await new Promise((r) => setTimeout(r, 20));
    expect(await s.listSampleIds()).toEqual(['sb']);
  });

  it('replacing a track sample deletes the old one', async () => {
    const { mk } = setup();
    const s = mk();
    let p = addTrack(createProject(), 'A', 'ta');
    await s.putSample('old', sample());
    p = setTrackSample(p, 'ta', 'old');
    s.set(p);
    await s.putSample('new', sample());
    s.set(setTrackSample(p, 'ta', 'new'));
    await new Promise((r) => setTimeout(r, 20));
    expect(await s.listSampleIds()).toEqual(['new']);
  });

  it('load removes samples that no track references', async () => {
    const { mk } = setup();
    const a = mk();
    a.set(createProject());
    await a.flush();
    await a.putSample('stray', sample());
    const b = mk();
    await b.load();
    expect(await b.listSampleIds()).toEqual([]);
  });

  it('deleteProject removes project and samples', async () => {
    const { mk } = setup();
    const s = mk();
    s.set(createProject());
    await s.flush();
    await s.putSample('x', sample());
    await s.deleteProject();
    expect(s.get()).toBeNull();
    expect(await mk().load()).toBeNull();
    expect(await s.listSampleIds()).toEqual([]);
  });

  it('deleteProject cancels a pending save', async () => {
    const { mk, timers } = setup();
    const s = mk();
    s.set(createProject());
    await s.deleteProject();
    expect(timers).toHaveLength(0);
    await s.flush();
    expect(await mk().load()).toBeNull();
  });

  it('clearAll empties both stores and registerClear hooks it up', async () => {
    const { mk } = setup();
    const s = mk();
    s.set(createProject());
    await s.flush();
    await s.putSample('x', sample());
    const hooks: Array<() => Promise<void> | void> = [];
    s.registerClear((h) => hooks.push(h));
    expect(hooks).toHaveLength(1);
    await hooks[0]!();
    expect(await mk().load()).toBeNull();
    expect(await s.listSampleIds()).toEqual([]);
  });

  it('putSample/getSample/deleteSample', async () => {
    const { mk } = setup();
    const s = mk();
    expect(await s.getSample('nope')).toBeNull();
    await s.putSample('a', sample());
    expect(await s.getSample('a')).not.toBeNull();
    await s.deleteSample('a');
    expect(await s.getSample('a')).toBeNull();
  });
});

describe('persisted mixer migration',()=>{
 const legacyProject=()=>{const p=addTrack(createProject(),'Lead','a');return {...p,tracks:[{...p.tracks[0]!,mix:{volumeDb:-6,pan:.25,eq:{bypass:false,trimDb:2,bands:[{id:'band',type:'bell',enabled:true,freq:700,gain:3,q:1,slope:12}]},reverb:{algorithm:'room',bypass:true,wet:.4}}}]} as unknown as ReturnType<typeof createProject>;};
 async function open(idb:IDBFactory){return new Promise<IDBDatabase>((resolve,reject)=>{const request=idb.open('sa3daw',1);request.onsuccess=()=>resolve(request.result);request.onerror=()=>reject(request.error);});}
 async function read(db:IDBDatabase){return new Promise<ReturnType<typeof createProject>>((resolve,reject)=>{const request=db.transaction('project').objectStore('project').get('current');request.onsuccess=()=>resolve(request.result);request.onerror=()=>reject(request.error);});}
 function checkMix(m:any){expect(m).toMatchObject({volumeDb:-6,pan:.25,plugins:[{type:'eq',bypass:false,settings:{trimDb:2,bands:[{freq:700,gain:3}]}},{type:'reverb',bypass:true,settings:{algorithm:'room',wet:.4}}]});expect(m).not.toHaveProperty('eq');expect(m).not.toHaveProperty('reverb');}
 it('loads legacy inserts and writes only the migrated schema after a tempo edit',async()=>{
  const {idb,mk}=setup(),primer=mk();await primer.load();await primer.close();const db=await open(idb);
  await new Promise<void>((resolve,reject)=>{const tx=db.transaction('project','readwrite');tx.oncomplete=()=>resolve();tx.onerror=()=>reject(tx.error);tx.objectStore('project').put(legacyProject(),'current');});
  const store=mk(),loaded=(await store.load())!;checkMix(loaded.tracks[0]!.mix);store.update(p=>({...p,bpm:97}));await store.flush();const saved=await read(db);expect(saved.bpm).toBe(97);checkMix(saved.tracks[0]!.mix);await store.close();db.close();
 });
 it('normalizes legacy inserts passed directly to save before writing IndexedDB',async()=>{
  const {idb,mk}=setup(),store=mk();store.save(legacyProject());await store.flush();const db=await open(idb);checkMix((await read(db)).tracks[0]!.mix);await store.close();db.close();
 });
});
it('keeps arrangement, notes and source audio through IndexedDB reload',async()=>{
 const {mk}=setup(),store=mk();let p=addTrack(createProject(),'Lead','t');p=setTrackSample(p,'t','source');p.arrangement={blocks:[{id:'b',trackId:'t',startBar:5}]};await store.putSample('source',sample());store.set(p);await store.flush();const reloaded=mk();expect((await reloaded.load())?.arrangement).toEqual(p.arrangement);expect(await reloaded.getSample('source')).not.toBeNull();
});

describe('persisted trim',()=>{
 it('reloads a saved trim, drops a malformed one and loads legacy tracks without trim',async()=>{
  const {mk}=setup(),store=mk();
  let p=addTrack(addTrack(addTrack(createProject(),'A','a'),'B','b'),'C','c');
  p={...p,tracks:[{...p.tracks[0]!,trim:{start:.2,end:.9}},{...p.tracks[1]!,trim:{start:2,end:1}} as never,p.tracks[2]!]};
  store.save(p);await store.flush();
  const again=mk(),loaded=(await again.load())!;
  expect(loaded.tracks[0]!.trim).toEqual({start:.2,end:.9});
  expect(loaded.tracks[1]!.trim).toBeUndefined();
  expect('trim' in loaded.tracks[2]!).toBe(false);
 });
});

describe('persisted master chain and effect plugins',()=>{
 async function open(idb:IDBFactory){return new Promise<IDBDatabase>((resolve,reject)=>{const request=idb.open('sa3daw',1);request.onsuccess=()=>resolve(request.result);request.onerror=()=>reject(request.error);});}
 it('round-trips a master chain and effect settings through IndexedDB',async()=>{
  const {mk}=setup(),store=mk();let p=addTrack(createProject(),'Lead','t');
  p=addPlugin(p,MASTER_ID,'limiter',()=>'lim');p=updatePluginSettings(p,MASTER_ID,'lim',{ceiling:-2,release:250});p=addPlugin(p,MASTER_ID,'eq',()=>'eq1');p=setPluginBypass(p,MASTER_ID,'eq1',true);
  p=addPlugin(p,'t','delay',()=>'dl');p=updatePluginSettings(p,'t','dl',{sync:5,feedback:60});
  store.set(p);await store.flush();const loaded=(await mk().load())!;
  expect(masterChain(loaded).map(x=>[x.id,x.type,x.bypass])).toEqual([['lim','limiter',false],['eq1','eq',true]]);
  expect(masterChain(loaded)[0]!.settings).toMatchObject({threshold:0,ceiling:-2,release:250});
  expect(loaded.tracks[0]!.mix!.plugins[0]).toMatchObject({type:'delay',settings:{sync:5,feedback:60,mix:30}});
 });
 it('loads projects without a master chain unchanged and drops unknown plugin types',async()=>{
  const {idb,mk}=setup(),primer=mk();await primer.load();await primer.close();const db=await open(idb);
  const base=addTrack(createProject(),'Lead','t'),legacy={...base,masterPlugins:[{id:'x',type:'vocoder',bypass:false,settings:{}},{id:'c',type:'compressor',bypass:false,settings:{ratio:99,junk:1}}],
   tracks:[{...base.tracks[0]!,mix:{volumeDb:0,pan:0,plugins:[{id:'q',type:'warp',bypass:false,settings:{}}]}}]};
  await new Promise<void>((res,rej)=>{const tx=db.transaction('project','readwrite');tx.oncomplete=()=>res();tx.onerror=()=>rej(tx.error);tx.objectStore('project').put(legacy,'current');});
  const loaded=(await mk().load())!;expect(masterChain(loaded)).toEqual([{id:'c',type:'compressor',bypass:false,settings:{threshold:-18,ratio:20,attack:10,release:120,knee:6,makeup:0}}]);
  expect(loaded.tracks[0]!.mix!.plugins).toEqual([]);db.close();
  const plain=mk();plain.set(addTrack(createProject(),'Solo','s'));await plain.flush();expect(Object.hasOwn((await mk().load())!,'masterPlugins')).toBe(false);
 });
});

describe('persisted preset tracks',()=>{
 it('reloads a preset track and drops a preset type without an id',async()=>{
  const {mk}=setup(),store=mk();
  let p=addTrack(addTrack(addTrack(createProject(),'A','a'),'B','b'),'C','c');
  p={...p,tracks:[{...p.tracks[0]!,soundType:'preset',presetId:'grand'},{...p.tracks[1]!,soundType:'preset'} as never,{...p.tracks[2]!,presetId:7} as never]};
  store.save(p);await store.flush();
  const loaded=(await mk().load())!;
  expect(loaded.tracks[0]).toMatchObject({soundType:'preset',presetId:'grand'});
  expect(loaded.tracks[1]!.soundType).toBeUndefined();
  expect('presetId' in loaded.tracks[1]!).toBe(false);
  expect('presetId' in loaded.tracks[2]!).toBe(false);
 });
 it('keeps a preset track when its project has no samples to delete',async()=>{
  const {mk}=setup(),store=mk();let p=addTrack(createProject(),'A','a');
  p={...p,tracks:[{...p.tracks[0]!,soundType:'preset',presetId:'mini-piano'}]};
  store.set(p);await store.flush();
  expect((await mk().load())!.tracks[0]!.presetId).toBe('mini-piano');
 });
});
